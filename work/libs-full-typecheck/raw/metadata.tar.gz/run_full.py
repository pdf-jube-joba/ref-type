from pathlib import Path
import hashlib,json,os,subprocess
base=Path('/workspace/full-check-20261121');repo=Path('/workspace/ref-type')
statefile=base/'task-state.json';state=json.loads(statefile.read_text());dest=base/'repository-allocator'
packages=['cohomology_thom','k_theory_thom','relative_k_theory','clutching_linearization','compact_support_k','periodic_k_theory','topological_k_theory','bott_product']
command=['python3','scripts/check_all.py','libs','--state-dir',str(dest),'--cache-dir','libs/refcache','--memory-mib','0','--cache-budget-mib','16384','--checkpoint-seconds','1800','--min-free-mib','1024','--max-scope-targets','1024']
for package in packages:command+=['--split-package',package]
env=os.environ.copy()
for key in ['REF_TYPE_PROFILE_PHASES','REF_TYPE_PROFILE_DECLARATIONS','REF_TYPE_PROFILE_CONVERSION','REF_TYPE_PROFILE_STORAGE','REF_TYPE_PROFILE_COSTS','REF_TYPE_PROFILE_COSTS_PROGRESS_MS']:
 env.pop(key,None)
env['REF_TYPE_GRAPH_RESIDENT_MIB']='2048'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
record={'command':command,'environment':{'REF_TYPE_GRAPH_RESIDENT_MIB':'2048'},'cwd':str(repo),'source_commit':source_commit,'binary_sha256':sha(repo/'target/release/cli'),'driver_sha256':sha(repo/'scripts/check_all.py'),'resume_report':None}
(base/'allocator-full-command.json').write_text(json.dumps(record,indent=2)+'\n')
state.update(active_driver_state=str(dest),active_normal_probe=None,active_supervisor=None,active_worker=None,active_module=None,source_commit=source_commit,binary_sha256=record['binary_sha256'],driver_sha256=record['driver_sha256'])
statefile.write_text(json.dumps(state,indent=2)+'\n')
with Path(str(dest)+'.stdout').open('w') as out,Path(str(dest)+'.stderr').open('w') as err:
 result=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=err)
raise SystemExit(result.returncode)
