from pathlib import Path
import hashlib,json,os,subprocess,time
base=Path('/workspace/full-check-20261121');repo=Path('/workspace/ref-type');cargo='/workspace/.ref-type-toolchain/cargo/bin/cargo';env=os.environ.copy();env.update(RUSTUP_HOME='/workspace/.ref-type-toolchain/rustup',CARGO_HOME='/workspace/.ref-type-toolchain/cargo')
commands=[('build-current',[cargo,'+1.100.0','build','--locked','--release','-p','cli','-j','4']),('fmt-current',[cargo,'+1.100.0','fmt','-p','cli','--check']),('clippy-current',[cargo,'+1.100.0','clippy','--locked','--release','-p','cli','--no-deps','--target-dir','/workspace/allocator-build','--','-D','warnings']),('python-current',['python3','-m','py_compile','scripts/check_all.py']),('diff-current',['git','diff','--check'])]
record={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'checks':[]}
for name,command in commands:
 start=time.monotonic()
 with (base/(name+'.stdout')).open('w') as out,(base/(name+'.stderr')).open('w') as err:r=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=err)
 record['checks'].append({'name':name,'command':command,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start});record['binary_sha256']=hashlib.file_digest((repo/'target/release/cli').open('rb'),'sha256').hexdigest();(base/'checks-current.json').write_text(json.dumps(record,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
