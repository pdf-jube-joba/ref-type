from pathlib import Path
import datetime,json,os,shutil,time,subprocess
base=Path('/workspace/full-check-20261121');state=base/'repository-allocator';report=Path(json.loads((state/'latest.json').read_text())['report']);cache=Path('/workspace/ref-type/libs/refcache');output=base/'full-resource-samples.jsonl'
while True:
 try:r=json.loads(report.read_text())
 except (FileNotFoundError,json.JSONDecodeError):time.sleep(1);continue
 if r['outcome']!='running':break
 sample={'schema_version':2,'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'driver_verified':len(r['verified']),'free_bytes':shutil.disk_usage(base).free,'processes':[]}
 sample['cgroup']={parts[0]:int(parts[1]) for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines() if (parts:=line.split())[0] in ['anon','file','file_mapped','pgmajfault','workingset_refault_file']}
 for request in cache.glob('.check-*/request.json'):
  try:
   sup=int(request.parent.name.split('-')[1]);cmd=Path(f'/proc/{sup}/cmdline').read_bytes()
   if str(state).encode() not in cmd:continue
   children=[int(row.split()[0]) for row in subprocess.check_output(['ps','-eo','pid=,ppid='],text=True).splitlines() if int(row.split()[1])==sup]
   for pid in [sup]+children:
    proc=Path(f'/proc/{pid}');command=proc.joinpath('cmdline').read_bytes()
    if pid!=sup and b'--worker' not in command:continue
    entry={'pid':pid,'supervisor':pid==sup,'heap_temp_mapped_bytes':0,'node_temp_mapped_bytes':0,'private_cache_mapped_bytes':0,'published_cache_mapped_bytes':0}
    for line in proc.joinpath('maps').read_text().splitlines():
     parts=line.split(maxsplit=5)
     if len(parts)<6:continue
     a,b=parts[0].split('-');length=int(b,16)-int(a,16);path=parts[5]
     if path.endswith(' (deleted)'):
      entry['node_temp_mapped_bytes' if 'ref-type-nodes-' in path else 'heap_temp_mapped_bytes']+=length
     elif str(request.parent) in path:entry['private_cache_mapped_bytes']+=length
     elif str(cache) in path:entry['published_cache_mapped_bytes']+=length
    entry['node_spill_open_logical_bytes']=0;entry['node_spill_open_allocated_bytes']=0;seen=set()
    for fd in proc.joinpath('fd').iterdir():
     try:
      target=os.readlink(fd);st=fd.stat();identity=(st.st_dev,st.st_ino)
      if 'ref-type-nodes-' in target and identity not in seen:
       seen.add(identity);entry['node_spill_open_logical_bytes']+=st.st_size;entry['node_spill_open_allocated_bytes']+=st.st_blocks*512
     except (FileNotFoundError,PermissionError):pass
    entry['io']={line.split(':')[0]:int(line.split(':')[1]) for line in proc.joinpath('io').read_text().splitlines()}
    entry['status']={key:int(value.split()[0]) for line in proc.joinpath('status').read_text().splitlines() if (key:=line.split(':')[0]) in ['VmRSS','VmSize','RssAnon','RssFile'] and (value:=line.split(':',1)[1])}
    sample['processes'].append(entry)
  except (FileNotFoundError,ProcessLookupError,PermissionError):continue
 with output.open('a') as f:f.write(json.dumps(sample)+'\n')
 time.sleep(30)
print('observer finished',flush=True)
