from pathlib import Path
import collections,hashlib,json,subprocess,tarfile
BASE=Path('/workspace/full-check-20261121');REPO=Path('/workspace/ref-type');DEST=REPO/'work/libs-full-typecheck'
def read(p):return json.loads(Path(p).read_text())
def save(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,text=True).strip()
def archive(name,files):
 p=DEST/'raw'/(name+'.tar.gz');p.parent.mkdir(parents=True,exist_ok=True)
 with tarfile.open(p,'w:gz') as tar:
  for f,n in files:tar.add(f,arcname=n,recursive=False)
 return {'file':str(p.relative_to(DEST)),'sha256':sha(p),'bytes':p.stat().st_size}
state=read(BASE/'task-state.json');reportpath=Path(read(Path(state['active_driver_state'])/'latest.json')['report']);r=read(reportpath)
assert r['outcome']=='accepted',r['outcome']
assert set(r['targets'])==set(r['verified'])
assert set(r['newly_checked']).isdisjoint(r['reused'])
assert set(r['newly_checked'])|set(r['reused'])==set(r['targets'])
assert sha(REPO/'target/release/cli')==r['binary_sha256']
assert sha(REPO/'scripts/check_all.py')==r['driver_sha256']
source=read(reportpath.parent/'source.json');assert sha(reportpath.parent/'source.json')==r['source_sha256']
assert source==read(reportpath.parent/'source-final.json')
source_hashes={str(Path(path).relative_to(REPO)):hashlib.sha256(text.encode('utf-8')).hexdigest() for path,text in source['files'].items()}
save(BASE/'source-files-sha256.json',source_hashes)
files=[(BASE/'source-files-sha256.json','source-files-sha256.json'),(reportpath,'driver/report.json'),(reportpath.parent/'targets.json','driver/targets.json')]
for ext in ['stdout','stderr']:
 files.append((Path(str(Path(state['active_driver_state']))+'.'+ext),'driver/'+ext))
for p in reportpath.parent.iterdir():
 if p.suffix in ['.log','.stdout'] and not p.name[:5].isdigit():files.append((p,'driver/'+p.name))
coverage=set();current_checked=set();inherited_verified=set();inputs={};scope_summaries=[];native_resumes=0
for i,a in enumerate(r['attempts']):
 p=Path(a['report']);result=read(p)
 assert a['exit_code']==0 and a['outcome']=='accepted'
 assert result['outcome']=='accepted' and result['storage']['save_failures']==0
 paths={'.'.join(m) for m in result['verified_modules']};checked={'.'.join(m) for m in result['checked_modules']}
 native_resumes+=result['storage'].get('checkpoint_resumes',0)
 name=a['module'];wanted=set(r['targets']) if name is None else {t for t in r['targets'] if t==name or (not a['module_only'] and t.startswith(name+'.'))}
 assert wanted<=paths
 coverage.update(paths & set(r['targets']))
 if a.get('inherited'):inherited_verified.update(paths & set(r['targets']))
 else:current_checked.update(checked & set(r['targets']))
 label=f'{i:05d}-'+p.stem
 files.extend([(p,'scopes/'+label+'.json'),(Path(a['log']),'scopes/'+label+'.log')])
 out=p.with_suffix('.stdout')
 if out.exists():files.append((out,'scopes/'+label+'.stdout'))
 entry=r['package_entries'].get(name.split('.')[0],source['entry']) if name else source['entry']
 expected=dict(source,entry=entry)
 inputs[label]={'sha256_reconstructed_from_frozen_root':hashlib.sha256((json.dumps(expected,ensure_ascii=False,indent=2)+'\n').encode()).hexdigest(),'entry':entry,'basis':'driver creates shared scope-source.json from fixed root and recorded package_entries; driver validates its digest before every CLI; per-scope snapshot bodies are not retained'}
 scope_summaries.append({'module':name,'module_only':a['module_only'],'inherited':a.get('inherited',False),'verified':len(paths),'checked':len(checked),'reused':len(paths-checked)})
assert coverage==set(r['targets'])
lastscope=reportpath.parent/'scope-source.json';lastinput=list(inputs.values())[-1];assert sha(lastscope)==lastinput['sha256_reconstructed_from_frozen_root'];last_actual={'sha256_observed':sha(lastscope),'entry':read(lastscope)['entry']};save(BASE/'last-scope-input-observed.json',last_actual);files.append((BASE/'last-scope-input-observed.json','last-scope-input-observed.json'))
save(BASE/'scope-input-hashes.json',inputs);files.append((BASE/'scope-input-hashes.json','scope-input-hashes.json'))
save(BASE/'scope-summaries.json',scope_summaries);files.append((BASE/'scope-summaries.json','scope-summaries.json'))
if r.get('resumed_from'):
 previous=Path(r['resumed_from']);assert sha(previous)==r['resumed_report_sha256'];old=read(previous)
 assert old['binary_sha256']==r['binary_sha256'] and old['source_sha256']==r['source_sha256'] and old['targets']==r['targets']
 assert read(previous.parent/'source.json')==source
 files.append((previous,'inherited-driver-report.json'))
final={k:r.get(k) for k in ['commit','outcome','binary_sha256','driver_sha256','source_sha256','memory_mib','cache_budget_mib','checkpoint_seconds','max_scope_targets','split_packages','resumed_from','resumed_report_sha256','inherited_target_count','execution_metrics_scope','elapsed_seconds','peak_rss_kib','save_failures','corrupt_cache_reads','checkpoint_resumes','worker_recoveries']}
run=read(BASE/'allocator-full-command.json');assert run['source_commit']==r['commit'] and run['binary_sha256']==r['binary_sha256'] and run['driver_sha256']==r['driver_sha256']
final.update(command=run['command'],environment=run['environment'],cwd=run['cwd'],native_storage_checkpoint_resumes_sum=native_resumes,source_file_count=len(source_hashes),source_files_sha256=sha(BASE/'source-files-sha256.json'),targets=len(r['targets']),verified=len(r['verified']),checked=len(r['newly_checked']),reused=len(r['reused']),unverified=0,current_scope_checked_module_union=len(current_checked),new_targets_verified_by_current_scopes=len(set(r['targets'])-inherited_verified),artifact=archive('repository-accepted',files))
probes={}
for name in ['refine','coefficients-profile','refine-costs','refine-tuned','allocator-std','allocator-default-std','cohom-allocator','cohom-hints','cohom-normal','alias-fiber']:
 p=BASE/(name+'.json')
 if not p.exists():continue
 q=read(p);f=[(BASE/(name+'.'+ext),name+'.'+ext) for ext in ['json','stdout','stderr']]
 for extra in BASE.glob(name+'-worker-*'):f.append((extra,extra.name))
 for extra in [BASE/(name+'-stop.json'),BASE/(name+'-request.json')]:
  if extra.exists():f.append((extra,extra.name))
 probes[name]={'outcome':q['outcome'],'verified':len(q.get('verified_modules',[])),'checked':len(q.get('checked_modules',[])),'reused':len(q.get('verified_modules',[]))-len(q.get('checked_modules',[])),'execution':q['execution'],'storage':q['storage'],'artifact':archive(name,f)}
metadata=[(p,p.name) for p in BASE.iterdir() if p.is_file() and p.name!='task-state.json' and (p.suffix in ['.json','.jsonl','.txt'] or p.name.endswith(('.stdout','.stderr'))) and not p.name.endswith('-source.json') and not p.name.startswith(('main-source','main-targets','refine','coefficients-profile','cohom-hints-worker','cohom-allocator-worker'))]
metadata.extend((BASE/name,name) for name in ['collect_evidence.py','run_full.py','run_checks.py','resource_observer.py'] if (BASE/name).exists())
oldpath=Path(state['old_driver_report']);old=read(oldpath);metadata.append((oldpath,'prior-driver/report.json'))
for p in oldpath.parent.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.stdout'] and 'source' not in p.name and p.name!='report.json':metadata.append((p,'prior-driver/'+p.name))
smoke=Path(read(BASE/'driver-smoke/latest.json')['report']);sm=read(smoke);assert sm['outcome']=='accepted'
metadata.extend((p,'smoke/'+p.name) for p in smoke.parent.iterdir() if p.suffix in ['.json','.log','.stdout'] and 'source' not in p.name)
e={'schema_version':1,'base_commit':state['base'],'source_commit':r['commit'],'branch':state['branch'],'pr':{'number':state.get('pr_number'),'url':state.get('pr_url')},'validation':read(BASE/'checks-current.json'),'post_check_source_identity':read(BASE/'post-check-verification.json'),'resource_samples_summary':read(BASE/'resource-sample-summary.json'),'first_actual_type_error':None,'first_environment_limit':None,'reference_or_manifest_changes':git('diff','--name-only',state['base'],r['commit'],'--','*.ref','*.toml').splitlines(),'semantic_checker_changes':git('diff','--name-only',state['base'],r['commit'],'--','src',':(exclude)src/cli').splitlines(),'cli_runtime_changes':git('diff','--name-only',state['base'],r['commit'],'--','src/cli').splitlines(),'driver_changed_files':git('diff','--name-only',state['base'],r['commit'],'--','scripts').splitlines(),'final':final,'prior_driver':{'outcome':old['outcome'],'targets':len(old['targets']),'verified':len(old['verified']),'checked':len(old['newly_checked']),'reused':len(old['reused']),'unverified':len(set(old['targets'])-set(old['verified'])),'binary_sha256':old['binary_sha256'],'source_sha256':old['source_sha256'],'report':'metadata archive prior-driver/report.json'},'probes':probes,'driver_smoke':{'outcome':sm['outcome'],'targets':len(sm['targets']),'verified':len(sm['verified']),'checked':len(sm['newly_checked']),'reused':len(sm['reused'])},'metadata_artifact':archive('metadata',metadata),'interpretation':{'aggregate_counts':('Final driver checked/reused categories include inherited identical-input accepted scopes; current invocation execution metrics exclude inherited runtime.' if r.get('resumed_from') else 'Fresh driver invocation with no inherited scopes. Final checked/reused categories partition all targets; normal validated cache reuse and internal checkpoints are distinct from driver report resume.'),'probe_counts':'Each probe is independent. Interrupted probes and partial worker events are diagnostic history, not accepted coverage.','resource_samples':'30-second external read-only /proc and cgroup samples. Empty process arrays mean no process detail was observed, not zero temporary storage. Version2 records heap mapped bytes and open node-spill allocated blocks separately; mapped bytes do not include unmapped allocation padding. CLI reports provide persistent-cache upper bounds.',
'cache':'Normal validated cache and normal internal checkpoints were used. No full-check, no no-cache, no fabricated cache entries.','profiling':'Read-only GDB backtraces briefly paused workers during diagnostic probes and detached. Probe elapsed times include those pauses. The final global driver ran without debugger attachment.',
'snapshots':'Actual root snapshot hash is recorded by the driver. Per-scope hashes are deterministically reconstructed from that frozen root and report.package_entries using the driver serialization; individual scope bodies are not retained. The final shared scope actual hash is separately observed and matched. Source file hashes are portable across checkout paths.','normal_probe_source':'Early probes through cohom-normal used base_commit mathematical sources. alias-fiber uses four imports simplified to inherited LocalTheory aliases at its recorded source commit. Each normal cache validates its own actual inputs. The final driver is fresh for its actual binary and source snapshot. Baseline canonical input identity is recorded in baseline.json.'}}
DEST.mkdir(parents=True,exist_ok=True);save(DEST/'evidence.json',e);print(json.dumps(final,indent=2))
